﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceAhead : MonoBehaviour
{
    GameControlScript gcont;
    public Vector2 offset;
    Transform cam;
    // Start is called before the first frame update
    void Start()
    {
        gcont = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControlScript>();
        cam = Camera.main.transform;
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log(gcont.roomAng);
        Vector2 newoffset = offset.Rotate(gcont.roomAng - offset.Ang());
        Vector3 noff3d = new Vector3(newoffset.x, newoffset.y, 90f);
        transform.position = cam.position + noff3d;
        transform.up = -newoffset.normalized;
    }
}
