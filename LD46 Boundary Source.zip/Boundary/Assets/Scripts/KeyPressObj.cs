﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class KeyPressObj : MonoBehaviour
{
    public KeyCode controlKey;
    bool active = false;
    int state = 0; // 0 - Idle; 1 - Active; 2 - Cooldown

    float stateTimer = 0;
    float activeInterval = .5f;
    float cooldownInterval = 1f;

    TilemapRenderer rend;
    TilemapCollider2D col;
    Tilemap map;
    GameControlScript gcont;

    // Start is called before the first frame update
    void Start()
    {
        col = GetComponent<TilemapCollider2D>();
        rend = GetComponent<TilemapRenderer>();
        map = GetComponent<Tilemap>();
        gcont = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControlScript>();

        TurnReady();
    }

    // Update is called once per frame
    void Update()
    {
        stateTimer += Time.deltaTime;

        switch (state)
        {
            case 0:
                if (Input.GetKeyDown(controlKey))
                {
                    TurnOn();
                }
                break;
            case 1:
                if (stateTimer > activeInterval)
                {
                    TurnOff();
                }
                break;
            case 2:
                if (stateTimer > cooldownInterval)
                {
                    TurnReady();
                }
                break;
            default:
                break;
        }
    }
    void TurnOn()
    {
        map.color = Color.white;
        rend.enabled = true;
        col.enabled = true;
        stateTimer = 0;
        state = 1;
    }
    void TurnOff()
    {
        rend.enabled = false;
        col.enabled = false;
        stateTimer = 0;
        state = 2;
    }
    void TurnReady()
    {
        map.color = Color.grey;
        rend.enabled = true;
        col.enabled = false;
        stateTimer = 0;
        state = 0;
    }
    public void Reset()
    {
        TurnReady();
    }
}
