﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using GlobalStructures;

public class TriggerObj : MonoBehaviour
{
    public bool inverted = false;
    int state = 0; // 0 - Idle; 1 - Active; 2 - Cooldown

    float stateTimer = 0;
    float activeInterval = .35f;
    float cooldownInterval = .35f;

    Color startColor;
    Color cooldownColor = new Color(0f,0f,0f,0f);
    Color readyColor = Color.grey;


    TilemapRenderer rend;
    TilemapCollider2D col;
    Tilemap map;
    GameControlScript gcont;
    float resetTime;

    public ActiveType actType;
    public TriggerType trigType;
    public ReqType reqType;
    public KeyCode controlKey;
    public int startHitPoints;
    [HideInInspector]
    public int hitPoints;


    // Start is called before the first frame update
    void Start()
    {
        col = GetComponent<TilemapCollider2D>();
        rend = GetComponent<TilemapRenderer>();
        map = GetComponent<Tilemap>();
        startColor = map.color;
        gcont = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControlScript>();
        hitPoints = startHitPoints;

        TurnReady();
    }

    // Update is called once per frame
    void Update()
    {
        stateTimer += Time.deltaTime;
        switch (state)
        {
            case 0:
                if (trigType == TriggerType.Key && Input.GetKeyDown(controlKey))
                {
                    TurnOn();
                }
                break;
            case 1:
                if (actType != ActiveType.Set && stateTimer > activeInterval)
                {
                    TurnOff();
                }
                break;
            case 2:
                if (stateTimer > cooldownInterval)
                {
                    TurnReady();
                }
                break;
            default:
                break;
        }
    }
    void TurnOn()
    {
        // If Multihit, wait till real turnon time
        if (reqType == ReqType.MultiHit && hitPoints > 1)
        {
            hitPoints -= 1;
            Debug.Log(hitPoints);
            return;
        }

        if (inverted)
        {
            map.color = cooldownColor;
            col.enabled = false;
        }
        else
        {
            map.color = startColor;
            col.enabled = true;
        }
        stateTimer = 0;
        state = 1;
    }
    void TurnOff()
    {
        if (inverted)
        {
            map.color = startColor;
            col.enabled = true;
        }
        else
        {
            map.color = cooldownColor;
            col.enabled = false;
        }
        stateTimer = 0;
        state = 2;
    }
    void TurnReady()
    {
        if (inverted)
        {
            map.color = startColor;
            col.enabled = true;
        }else
        {
            map.color = readyColor;
            col.enabled = false;
        }
        stateTimer = 0;
        state = 0;
    }

    public void Reset()
    {
        if (trigType == TriggerType.Trigger)
        {
            resetTime = Time.time;
        }
        TurnReady();
        hitPoints = startHitPoints;
    }

    public float GetReadyProgress()
    {
        float timer = stateTimer;
        if (state == 2)
        {
            timer += activeInterval;
        }
        return timer / (activeInterval + cooldownInterval);
    }
    public int GetState()
    {
        return state;
    }

    public void TriggerExitFunc(Collider2D col)
    {
        if (Time.time - resetTime < .2f)
        {
            return;
        }
        if (trigType == TriggerType.Trigger && state == 0 && col.tag == "Player")
        {
            TurnOn();
        }
    }
}
