﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MultiHitUIController : MonoBehaviour
{
    public TriggerObj trigObj;
    public char textval;
    public Transform followTransform;
    Text text;
    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<Text>();
        text.text = trigObj.hitPoints.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        text.text = trigObj.hitPoints.ToString();
        if (followTransform)
        {
            transform.position = Camera.main.WorldToScreenPoint(followTransform.position);
        }
        if (trigObj.GetState() != 0)
        {
            text.enabled = false;
        }
        else
        {
            text.enabled = true;
        }

    }
}
