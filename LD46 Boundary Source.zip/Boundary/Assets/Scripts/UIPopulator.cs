﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using GlobalStructures;

public class UIPopulator : MonoBehaviour
{
    KeyCode[] keys;
    char[] chars;
    Dictionary<KeyCode, char> key2char;
    //Sprite[] images;
    public GameObject keyUIPrefab;
    public GameObject multiHitUIPrefab;
    // Start is called before the first frame update
    void Start()
    {
        keys = new KeyCode[] { KeyCode.Q, KeyCode.W, KeyCode.E, KeyCode.R, KeyCode.T};
        chars = new char[] { 'Q', 'W', 'E', 'R', 'T' };
        key2char = new Dictionary<KeyCode, char>();
        for (int i = 0; i < keys.Length; i++)
        {
            key2char.Add(keys[i], chars[i]);
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void LoadUI(GameObject room)
    {
        // Destroy the ones from the last level
        int childCount = transform.childCount;
        for (int i = 0; i < childCount; i++)
        {
            Destroy(transform.GetChild(i).gameObject);
        }
        
        //Create the new ones
        TriggerObj[] trigObjs = room.transform.GetChild(0).GetComponentsInChildren<TriggerObj>();
        foreach (TriggerObj trigObj in trigObjs)
        {
            Transform t = trigObj.transform.GetChild(0);
            if (t.tag != "UILocation") { Debug.Log("Error in setting UI location for object: " + trigObj.name); continue; }
            Vector3 newpos = Camera.main.WorldToScreenPoint(trigObj.transform.GetChild(0).position);
            if (trigObj.trigType == TriggerType.Key)
            {
                GameObject UIObj = Instantiate(keyUIPrefab, newpos, Quaternion.identity, transform);
                KeyUIController UICont = UIObj.GetComponent<KeyUIController>();
                UICont.followTransform = t;
                UICont.trigObj = trigObj;
                UICont.textval = key2char[trigObj.controlKey];
            }else if (trigObj.reqType == ReqType.MultiHit)
            {
                GameObject UIObj = Instantiate(multiHitUIPrefab, newpos, Quaternion.identity, transform);
                MultiHitUIController UICont = UIObj.GetComponent<MultiHitUIController>();
                UICont.followTransform = t;
                UICont.trigObj = trigObj;
            }
        }
    }
}
