﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameControlScript : MonoBehaviour
{
    public float loadTimer = 99f;
    public float loadInterval;
    public string firstScene;
    [HideInInspector]
    public float roomAng;
    //bool levelLoaded = false;
    int loadState = 0; //0 - Loaded Level, 1 - Loaded Transition
    int lastLoadState = 0;
    public Vector2 roomOffset;
    public GameObject EffectObj;
    Ball player;
    GameObject room;
    UIPopulator UILoader;
    AudioController audioControl;
    public GameObject retryUI;
    Canvas canvas;
    GameObject retryUIInstance;

    //Color Control
    /*public Color bounceColor;
    public Color InactiveColor;
    public Color goalColor;*/

    string lastLevelScene;
    string levelScene;
    string transScene;

    void Awake()
    {
        levelScene = firstScene;
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Ball>();
        canvas = GameObject.FindGameObjectWithTag("UILoader").GetComponent<Canvas>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
        SceneManager.LoadScene(firstScene, LoadSceneMode.Single);
        room = GameObject.FindGameObjectWithTag("Room");
        audioControl = GetComponent<AudioController>();
    }
    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
        //Debug.Log("OnEnable called");
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        roomAng = (player.vel).Ang() - ((Vector2)transform.right).Ang();
        if (scene.name == levelScene)
        {
            //Set state to level is loaded
            loadState = 0;

            //Room Placement
            room = GameObject.FindGameObjectWithTag("Room");
            room.transform.position = player.transform.position + (Vector3)(roomOffset.magnitude * player.vel.normalized);
            room.transform.Rotate(Vector3.forward, roomAng * Mathf.Rad2Deg);
            
            //Audio Check
            audioControl.SetAudio(room.GetComponentInChildren<AudioInfoHolder>().getTrack());
            
            //UI Information
            UILoader = GameObject.FindGameObjectWithTag("UILoader").GetComponent<UIPopulator>();
            UILoader.LoadUI(room);

        }
        else if (scene.name == transScene)
        {
            loadState = 1;
        }else
        {
            Debug.Log("Scene Load Mismatch");
        }

    }

    // Update is called once per frame
    void Update()
    {
        loadTimer += Time.deltaTime;
        if (loadState != lastLoadState && loadTimer > loadInterval)
        {
            switch (loadState)
            {
                case 1:
                    SceneManager.UnloadSceneAsync(lastLevelScene);
                    SceneManager.LoadSceneAsync(levelScene, LoadSceneMode.Additive);
                    lastLoadState = 1;
                    break;
                case 0:
                    lastLoadState = 0;
                    SceneManager.UnloadSceneAsync(transScene);
                    
                    break;
                default:
                    break;
            
            }
        }
    }

    public void StartLoading(string tScene, string lScene)
    {
        lastLevelScene = SceneManager.GetActiveScene().name;
        levelScene = lScene;
        transScene = tScene;
        SceneManager.LoadSceneAsync(tScene, LoadSceneMode.Additive);
        loadTimer = 0; // Reset timer and then wait at least loadInterval long
    }
    void OnDisable()
    {
        //Debug.Log("OnDisable called");
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    public void Death()
    {
        //TODO reset all level features
        TriggerObj[] trigobjs = room.transform.GetChild(0).GetComponentsInChildren<TriggerObj>();
        foreach (TriggerObj trigobj in trigobjs)
        {
            trigobj.Reset();
        }
        retryUIInstance =  Instantiate(retryUI, canvas.transform, false);
        
    }
    public void Revive()
    {
        Destroy(retryUIInstance);
    }

    public void PlayEffect(AudioClip clip)
    {
        GameObject o = Instantiate(EffectObj);
        AudioSource source = o.GetComponent<AudioSource>();
        source.clip = clip;
        source.Play();
        Destroy(o, clip.length * 3f);
    }
}
