﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallChaser : MonoBehaviour
{
    public Vector2 offset;
    Transform target;
    Ball ball;

    void Awake()
    {

    }
    
    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").transform;
        ball = target.GetComponent<Ball>();
        Update();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 newpos = target.transform.position + (Vector3)(offset.magnitude * ball.vel.normalized);
        newpos.z = transform.position.z;
        transform.position = newpos;
    }
}
