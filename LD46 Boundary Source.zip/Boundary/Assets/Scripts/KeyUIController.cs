﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KeyUIController : MonoBehaviour
{
    public TriggerObj trigObj;
    public char textval;
    public Transform followTransform;
    GameObject clock;
    GameObject keyPic;
    Text key;
    Image clockTop;
    // Start is called before the first frame update
    void Start()
    {
        keyPic = transform.GetChild(0).gameObject;
        key = keyPic.GetComponentInChildren<Text>();
        clock = transform.GetChild(1).gameObject;
        clockTop = clock.transform.GetChild(1).GetComponent<Image>();
        
        key.text = textval.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (followTransform)
        {
            transform.position = Camera.main.WorldToScreenPoint(followTransform.position);
        }
        if (trigObj.GetState() != 0)
        {
            keyPic.SetActive(false);
            clock.SetActive(true);
            clockTop.fillAmount = trigObj.GetReadyProgress();
        }else
        {
            keyPic.SetActive(true);
            clock.SetActive(false);
        }

    }
}
