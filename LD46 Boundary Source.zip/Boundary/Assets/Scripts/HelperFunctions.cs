﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class HelperFunctions
{

    /*public static Vector3 SetZ(Vector3 v, float f){
		Vector3 n = v;
		n.z = f;
		return n;
	}*/

    public static Vector2 Rotate(this Vector2 a, float addAng)
    {
        float newAng = a.Ang() + addAng;
        return new Vector2(Mathf.Cos(newAng), Mathf.Sin(newAng)) * a.magnitude;
    }

    public static Vector2 Snap(this Vector2 a, float snapAngleReso)
    {
        float snapAng = Mathf.Round(a.Ang() / snapAngleReso) * snapAngleReso;
        //Debug.Log(snapAng);
        return new Vector2(Mathf.Cos(snapAng), Mathf.Sin(snapAng)) * a.magnitude;
    }

    public static Vector2 Reflect(this Vector2 a, Vector2 b)
    {
        // Reflect Vector b around a
        float angdiff = b.Ang()-a.Ang();
        float tan = Mathf.Sin(angdiff) * b.magnitude;
        float norm = Mathf.Cos(angdiff) * b.magnitude;
        return - norm*a.normalized + tan * a.normalized.Rot90();
    }

    public static float Dot(this Vector2 a, Vector2 b)
    {
        return (a.x * b.x) + (a.y * b.y);
    }

    public static float Ang(this Vector2 a)
    {
        return Mathf.Atan2(a.y, a.x);
    }

    public static Vector2 Rot90(this Vector2 a)
    {
        return new Vector2(-a.y, a.x);
    }
}
