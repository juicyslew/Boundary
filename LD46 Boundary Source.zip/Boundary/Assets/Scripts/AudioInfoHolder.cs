﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioInfoHolder : MonoBehaviour
{
    public int track;
    public int getTrack() {
        return track;
    }
}
