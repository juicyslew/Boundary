﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    //General Vars
    GameControlScript gcont; 
    public Vector2 vel;

    //Collision Vars
    Rigidbody2D myBody;
    RaycastHit2D hitInfo;
    Vector2 prevPos;
    public LayerMask collideMask = -1;
    float radius = 1f;

    //Death Vars
    int state = 0; //0 - Default; 1 - dying; 2 - spawned
    //float deathTimer = 0f;
    //float deathInterval = .5f;
    SpriteRenderer srend;
    ParticleSystem trailpart;
    public GameObject deathpartobj;
    Color deathStartColor = new Color(1f, 0f, 0f, 1f);
    Color deathEndColor = new Color(0f,0f,0f,0f);
    SpawnScript Spawner;
    Animator animator;
    public AudioClip[] hitSounds;
    public AudioClip deathSound;
    public AudioClip goalSound;
    ScreenShaker scrShaker;

    
    // Start is called before the first frame update
    void Start()
    {
        myBody = GetComponent<Rigidbody2D>();
        CircleCollider2D myCol = GetComponent<CircleCollider2D>();
        radius = Mathf.Max(myCol.bounds.extents.x, myCol.bounds.extents.y);
        prevPos = transform.position;
        srend = GetComponent<SpriteRenderer>();
        gcont = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControlScript>();
        trailpart = transform.GetChild(0).GetComponent<ParticleSystem>();
        animator = GetComponent<Animator>();
        scrShaker = Camera.main.GetComponent<ScreenShaker>();
    }

    // Update is called once per frame
    void Update()
    {
        switch (state)
        {
            case 0:
                transform.position = transform.position + (Vector3)vel * Time.deltaTime;
                break;
            //case //1:
                /*deathTimer += Time.deltaTime;
                //srend.color = Color.Lerp(deathStartColor, deathEndColor, deathTimer / deathInterval);
                if (deathTimer > deathInterval) // When animation is done
                {
                    //gcont.Death(); //Currently empty
                    state = 2;
                }
                break;*/
            case 1: //Awaiting being spawned
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    vel = Spawner.vel;
                    animator.SetTrigger("Shot");
                    gcont.Revive();
                    trailpart.Play();
                    Spawner.Disappear();
                    state = 0;
                }
                break;
            default:
                break;
        }
    }

    public virtual void FixedUpdate()
    {

        Debug.DrawRay (transform.position, (Vector3) vel, Color.green);
        //Debug.Log("Wowow!");

        Vector2 tvel = vel * Time.fixedDeltaTime;

        Vector2 scratchPos = prevPos;
        float movementMagnitude = tvel.magnitude;
        bool breakflag = false;
        for (int i = 0; i < 5; i++)
        {
            hitInfo = Physics2D.CircleCast(scratchPos, radius, vel, movementMagnitude, collideMask.value); //CircleCast(previousPosition, radius, movementThisStep, movementMagnitude, collideMask.value); 
                                                                                                                           //check for obstructions we might have missed 
            if (hitInfo)
            {
                if (hitInfo.collider)
                {
                    //Debug.Log("Hit: " + hitInfo.collider.name);
                    Debug.DrawRay(hitInfo.point, (Vector3)hitInfo.normal *3f, Color.red);
                    Collider2D col = hitInfo.collider;
                    switch (col.tag)
                    {
                        case "Bouncer":
                            //Debug.Log((scratchPos - hitInfo.centroid).magnitude);
                            int soundind = Random.Range(0, hitSounds.Length);
                            //Debug.Log("soundind: " + soundind);
                            gcont.PlayEffect(hitSounds[soundind]);
                            scrShaker.AddScreenShake(.1f);
                            movementMagnitude = movementMagnitude - (scratchPos - hitInfo.centroid).magnitude;
                            vel = hitInfo.normal.Reflect(vel).Snap(Mathf.PI/12f);
                            scratchPos = hitInfo.centroid;
                            break;
                        case "Killer":
                            scratchPos = Death();
                            breakflag = true;
                            break;
                        default:
                            break;
                    }
                }
                if (breakflag) break;
            }else
            {
                break;
            }
        }
        transform.position = scratchPos + vel.normalized * movementMagnitude;
        prevPos = transform.position;
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        switch (col.tag)
        {
            case "Goal":
                GoalScript gs = col.GetComponent<GoalScript>();
                gcont.PlayEffect(goalSound);
                gcont.StartLoading(gs.loadingScene, gs.nextLevelScene);
                break;
            default:
                break;
        }
    }

    Vector2 Death()
    {
        trailpart.Stop();
        GameObject deathobj = Instantiate(deathpartobj, transform.position, Quaternion.identity);
        ParticleSystem deathpart = deathpartobj.GetComponent<ParticleSystem>();
        ParticleSystem.VelocityOverLifetimeModule velmod = deathpart.velocityOverLifetime;

        velmod.x = vel.x;
        velmod.y = vel.y;
        vel = Vector2.zero;

        srend.enabled = false;
        gcont.Death();
        scrShaker.AddScreenShake(.5f);

        Spawner = GameObject.FindGameObjectWithTag("Spawn").GetComponent<SpawnScript>();
        Debug.DrawLine(transform.position, Spawner.transform.position, Color.cyan, 2f);
        prevPos = Spawner.transform.position;
        transform.position = Spawner.transform.position;
        animator.SetTrigger("Appear");
        Spawner.Appear();
        state = 1;
        gcont.PlayEffect(deathSound);

        return Spawner.transform.position;
    }
}
