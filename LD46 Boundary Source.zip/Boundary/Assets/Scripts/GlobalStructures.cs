﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GlobalStructures
{
    public enum ActiveType { Short, Set, Toggle };
    public enum TriggerType { Key, Trigger};
    public enum ReqType { None, MultiHit}
}
