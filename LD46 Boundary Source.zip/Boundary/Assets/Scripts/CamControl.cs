﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamControl : MonoBehaviour
{
    public Transform target;
    public float transsmooth;
    public float rotsmooth;
    GameControlScript gcont;
    // Start is called before the first frame update
    float mod(float x, float m)
    {
        float r = x % m;
        return r < 0 ? r + m : r;
    }
    void Start()
    {
        gcont = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameControlScript>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 poschange = (target.position - transform.position)/transsmooth;
        //Debug.Log("roomdeg: " + mod((gcont.roomAng * Mathf.Rad2Deg), 360f) + " | cameradeg: " + transform.rotation.eulerAngles.z);
        float rotchange = (mod((gcont.roomAng * Mathf.Rad2Deg), 360f) - transform.rotation.eulerAngles.z)/rotsmooth;
        poschange.z = 0;
        transform.position = transform.position + poschange;
        transform.Rotate(Vector3.forward, rotchange);
    }
}
