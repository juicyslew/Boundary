﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamTarget : MonoBehaviour
{
    CamControl camcontrol;
    // Start is called before the first frame update
    void Start()
    {
        camcontrol = Camera.main.transform.parent.gameObject.GetComponent<CamControl>();
        camcontrol.target = transform;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
